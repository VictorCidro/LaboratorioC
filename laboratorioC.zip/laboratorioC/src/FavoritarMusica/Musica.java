package FavoritarMusica;

import java.util.Objects;

public class Musica {
    private String titulo;
    private String artista;

    public Musica(String titulo, String artista) {
        this.titulo = titulo;
        this.artista = artista;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Musica outraMusica = (Musica) obj;
        return titulo.equals(outraMusica.titulo) && artista.equals(outraMusica.artista);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, artista);
    }
}