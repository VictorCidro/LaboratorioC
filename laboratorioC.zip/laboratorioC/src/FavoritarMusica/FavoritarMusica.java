package FavoritarMusica;

import java.util.ArrayList;
import java.util.List;

public class FavoritarMusica {
    private List<Musica> musicasFavoritadas = new ArrayList<>();

    // Outros métodos e construtores da classe MusicManager

    public void favoritarMusica(Musica musica) {
        if (!isMusicaFavoritada(musica)) {
            musicasFavoritadas.add(musica);
        }
    }

    public boolean isMusicaFavoritada(Musica musica) {
        return musicasFavoritadas.contains(musica);
    }
}