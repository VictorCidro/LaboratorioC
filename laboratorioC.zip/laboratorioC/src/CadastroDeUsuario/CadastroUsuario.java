package CadastroDeUsuario;

import java.util.ArrayList;
import java.util.List;

public class CadastroUsuario {

	private List<Usuario> usuariosCadastrados;

	public CadastroUsuario() {
	        usuariosCadastrados = new ArrayList<>();
	}

	public boolean cadastrarUsuario(Usuario usuario) {
	        
		if (!usuarioJaCadastrado(usuario.getEmail())) {
	            usuariosCadastrados.add(usuario);
	            return true; 
	    }
	        return false; 
	}

	    private boolean usuarioJaCadastrado(String email) {
	        for (Usuario u : usuariosCadastrados) {
	            if (u.getEmail().equals(email)) {
	                return true;
	            }
	        }
	        return false;
	    }
}
