package CriarPlaylist;

import java.util.ArrayList;
import java.util.List;

public class Playlist {

    private String nomePlaylist;
    private List<String> musicas;

    public Playlist() {
        musicas = new ArrayList<>();
    }

    public boolean criarPlaylist(String nome, List<String> musicas) {
        if (nome != null && !nome.isEmpty() && musicas != null && !musicas.isEmpty()) {
            this.nomePlaylist = nome;
            this.musicas = new ArrayList<>(musicas);
            return true;
        }
        return false;
    }

    public String getNomePlaylist() {
        return nomePlaylist;
    }

    public List<String> getMusicas() {
        return musicas;
    }

    public void adicionarMusica(String musica) {
        musicas.add(musica);
    }

    public void removerMusica(String musica) {
        musicas.remove(musica);
    }
}
