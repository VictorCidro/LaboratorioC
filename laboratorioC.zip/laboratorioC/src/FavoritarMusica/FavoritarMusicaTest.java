package FavoritarMusica;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class FavoritarMusicaTest {
    private FavoritarMusica favoritarMusica;

    @Before
    public void setUp() {
        favoritarMusica = new FavoritarMusica(); // Crie uma instância de FavoritarMusica
    }

    @Test
    public void testFavoritarMusica() {
        Musica music = new Musica("Song Title", "Artist");

        // Favorita a música
        favoritarMusica.favoritarMusica(music);

        // Verifica se a música foi favoritada corretamente
        assertTrue(favoritarMusica.isMusicaFavoritada(music));
    }

    @Test
    public void testDesfavoritarMusica() {
        Musica music = new Musica("Song Title", "Artist");

        // Favorita a música
        favoritarMusica.favoritarMusica(music);

        // Desfavorita a música
        favoritarMusica.favoritarMusica(music);

    }
}