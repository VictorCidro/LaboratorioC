package CriarPlaylist;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

public class PlaylistTest {

    @Test
    public void testCriarPlaylistValida() {
        Playlist manager = new Playlist();
        List<String> musicas = new ArrayList<>();
        musicas.add("Música 1");
        musicas.add("Música 2");
        assertTrue(manager.criarPlaylist("Minha Playlist", musicas));
        assertEquals("Minha Playlist", manager.getNomePlaylist()); // Corrigido para comparar o nome da playlist
    }

    @Test
    public void testCriarPlaylistInvalida() {
        Playlist manager = new Playlist();
        List<String> musicas = new ArrayList<>();
        assertFalse(manager.criarPlaylist("Playlist Inválida", musicas));
    }
}