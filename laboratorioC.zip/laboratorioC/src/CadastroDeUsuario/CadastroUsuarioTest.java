package CadastroDeUsuario;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class CadastroUsuarioTest {

    private CadastroUsuario cadastro;

    @Before
    public void setUp() {
        cadastro = new CadastroUsuario(); // Substitua CadastroUsuario pelo nome de sua classe de cadastro de usuário.
    }

    @Test
    public void testCadastroUsuarioValido() {
        Usuario usuario = new Usuario("Nome", "Email", "Senha");
        boolean resultado = cadastro.cadastrarUsuario(usuario);
        assertTrue(resultado);
    }

    @Test
    public void testCadastroUsuarioExistente() {
        Usuario usuario = new Usuario("NomeExistente", "EmailExistente", "SenhaExistente");
        cadastro.cadastrarUsuario(usuario);
        
        Usuario usuarioDuplicado = new Usuario("NomeExistente", "EmailExistente", "SenhaDiferente");
        boolean resultado = cadastro.cadastrarUsuario(usuarioDuplicado);
        assertFalse(resultado);
    }
}